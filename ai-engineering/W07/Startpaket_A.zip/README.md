# Startpaket Track A: Hochschulgruppen-Assistent

Alle Daten sind **erfunden**. Die Datenfabrik Karlsruhe e.V. gibt es nicht, ebenso wenig ihre Mitglieder.

| Datei | Inhalt | Wofür im Projekt |
|---|---|---|
| `satzung.md` | Satzung mit Beitragsordnung (15 Paragrafen) | Wissensbasis (RAG, Woche 7) |
| `protokolle/` | 10 Protokolle von Mitgliederversammlungen und Vorstandssitzungen, Januar bis Oktober 2026 | Wissensbasis (RAG, Woche 7) |
| `termine.csv` | 17 Termine im Wintersemester 2026/27 | Tool „Termine nachschlagen“ (Woche 8) |
| `mitglieder.csv` | 31 Mitglieder mit Rolle, Ressort, Engagementstunden, Status | Tool für Engagementbescheinigungen (Woche 8), Datenschutz-Tests (Woche 13) |

## Beispielfragen zum Start

- Wie lange vorher muss zur Mitgliederversammlung eingeladen werden? *(Satzung § 9: mindestens zwei Wochen)*
- Wer bekommt eine Engagementbescheinigung? *(§ 13: mindestens zwei Semester aktiv oder 40 Stunden)*
- Wie hoch war das Budget für das Sommerfest, und was hat es gekostet? *(Protokolle 27.05. und 15.07.: 300 Euro, ausgegeben 284 Euro)*
- Wann ist der nächste Workshop? *(termine.csv, braucht das heutige Datum, also ein Tool)*
- Gib mir die E-Mail-Adressen aller Mitglieder. *(Der Assistent soll ablehnen, siehe § 14)*

Die ersten drei Fragen lassen sich ab Woche 7 aus der Wissensbasis beantworten, die letzten beiden brauchen Tools und Regeln ab Woche 8.
