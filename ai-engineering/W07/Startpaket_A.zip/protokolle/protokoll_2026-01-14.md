# Protokoll Mitgliederversammlung vom 14.01.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Hörsaal am Fasanengarten
- **Anwesend:** 21 stimmberechtigte Mitglieder, 2 Fördermitglieder
- **Sitzungsleitung:** Paul Schröder (Versammlungsleitung)
- **Protokoll:** Felix Braun

## TOP 1: Satzungsänderung

Der Vorstand stellt die überarbeitete Satzung vor. Neu sind insbesondere § 13 (Engagementbescheinigungen) und § 14 (Datenschutz). Die Satzungsänderung wird mit 18 Ja-Stimmen, 1 Nein-Stimme und 2 Enthaltungen angenommen. Damit ist die erforderliche Zweidrittelmehrheit erreicht.

## TOP 2: Beitragsordnung

Die Beitragsordnung (Anlage der Satzung) wird einstimmig beschlossen. Der Beitrag für ordentliche Mitglieder bleibt bei 10 Euro pro Semester. Neu ist der Beitrag für Unternehmen als Fördermitglieder von 500 Euro pro Jahr.

## TOP 3: Wahl des Vorstands

Gewählt werden Lena Hofmann als erste Vorsitzende (19 Ja, 2 Enthaltungen), Jonas Weber als zweiter Vorsitzender (20 Ja, 1 Enthaltung) und Aylin Demir als Finanzvorständin (einstimmig). Alle nehmen die Wahl an.

## TOP 4: Wahl der Kassenprüfer

Ben Hartmann und Nora Vogel werden einstimmig zu Kassenprüfern gewählt.
