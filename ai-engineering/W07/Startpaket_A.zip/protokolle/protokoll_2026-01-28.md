# Protokoll Vorstandssitzung vom 28.01.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir; als Gast Sara Lindner
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Jonas Weber

## TOP 1: Planung Sommersemester 2026

Für das Sommersemester sind ein Python-Workshop, eine Exkursion und ein Sommerfest geplant. Aylin Demir erarbeitet einen Budgetvorschlag für die Mitgliederversammlung im April.

## TOP 2: Exkursion

Mia Krüger hat Kontakt zur Nordwerk GmbH aufgenommen. Eine Werksbesichtigung im Juni ist grundsätzlich möglich. Mia klärt bis Ende Februar einen Termin.

## TOP 3: Website

Die Website ist veraltet. Sara Lindner übernimmt den Relaunch mit dem Ressort IT. Ziel ist der 1. Juni 2026.
