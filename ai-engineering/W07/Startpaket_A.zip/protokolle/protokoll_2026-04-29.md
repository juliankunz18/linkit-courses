# Protokoll Mitgliederversammlung vom 29.04.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Hörsaal am Fasanengarten
- **Anwesend:** 17 stimmberechtigte Mitglieder
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Felix Braun

## TOP 1: Bericht des Vorstands

Lena Hofmann berichtet über das Wintersemester: zwei Workshops, ein Vortrag, 6 neue Mitglieder.

## TOP 2: Semesterbudget Sommersemester 2026

Aylin Demir stellt den Budgetvorschlag vor: insgesamt 2.400 Euro, davon Events 1.200 Euro, Exkursionen 600 Euro, Öffentlichkeitsarbeit 300 Euro, IT 150 Euro und Reserve 150 Euro. Das Budget wird mit 16 Ja-Stimmen und 1 Enthaltung beschlossen.

## TOP 3: Ressortleitungen

Der Vorstand benennt für das Sommersemester: Events Paul Schröder, Unternehmenskontakte Mia Krüger, Öffentlichkeitsarbeit Felix Braun, IT Sara Lindner.
