# Protokoll Vorstandssitzung vom 13.05.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir; als Gast Mia Krüger
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Aylin Demir

## TOP 1: Exkursion Nordwerk GmbH

Die Werksbesichtigung findet am 18. Juni 2026 statt. Für den Bus fallen 380 Euro an. Da die Ausgabe 250 Euro übersteigt, ist ein Vorstandsbeschluss nötig. Beschluss: Der Vorstand genehmigt die Ausgabe einstimmig. Sie wird aus dem Budget für Exkursionen bezahlt.

## TOP 2: Workshop Python für Einsteiger

Der Workshop findet am 27. Mai 2026 im PC-Pool statt. Sara Lindner leitet ihn, die Anmeldung läuft über die Website.
