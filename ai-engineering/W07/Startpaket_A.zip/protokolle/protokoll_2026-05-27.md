# Protokoll Vorstandssitzung vom 27.05.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir; als Gast Paul Schröder
- **Sitzungsleitung:** Jonas Weber
- **Protokoll:** Lena Hofmann

## TOP 1: Sommerfest

Das Sommerfest findet am 10. Juli 2026 im Café am Campus statt. Budget: 300 Euro aus dem Ressort Events. Paul Schröder organisiert.

## TOP 2: Fördermitgliedschaft Lindqvist Robotics

Die Lindqvist Robotics GmbH möchte Fördermitglied werden. Beschluss: Der Vorstand nimmt das Unternehmen als Fördermitglied auf (Beitrag 500 Euro pro Jahr gemäß Beitragsordnung). Mia Krüger ist Ansprechpartnerin.
