# Protokoll Vorstandssitzung vom 10.06.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Jonas Weber

## TOP 1: Website

Die neue Website ist seit dem 1. Juni 2026 online. Sara Lindner und das Ressort IT werden ausdrücklich gelobt.

## TOP 2: Hackathon im Wintersemester

Geplant ist ein Hackathon zum Thema „Daten in der Produktion“ am 28. und 29. November 2026. Das geschätzte Budget beträgt 1.400 Euro für Verpflegung, Raum und Preise. Da es 1.000 Euro übersteigt, muss die Mitgliederversammlung zustimmen. Der Punkt kommt auf die Tagesordnung der Mitgliederversammlung im November.
