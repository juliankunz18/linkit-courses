# Protokoll Vorstandssitzung vom 24.06.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir; als Gast Mia Krüger
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Aylin Demir

## TOP 1: Rückblick Exkursion

An der Werksbesichtigung bei der Nordwerk GmbH haben 24 Personen teilgenommen. Die Rückmeldungen waren sehr positiv. Mia Krüger schreibt einen kurzen Bericht für die Website.

## TOP 2: Anträge auf Engagementbescheinigungen

Drei Anträge liegen vor (Paul Schröder, Sara Lindner, Ben Hartmann). Alle erfüllen die Voraussetzungen nach § 13 der Satzung. Jonas Weber erstellt die Entwürfe bis zum 8. Juli, die Unterschrift erfolgt durch Lena Hofmann und Jonas Weber.

## TOP 3: Anfrage eines Unternehmens nach der Mitgliederliste

Ein Unternehmen hat nach der Mitgliederliste gefragt, um Praktikumsangebote zu verschicken. Beschluss: Die Liste wird gemäß § 14 nicht weitergegeben. Stattdessen veröffentlicht das Ressort Öffentlichkeitsarbeit die Angebote im Newsletter.
