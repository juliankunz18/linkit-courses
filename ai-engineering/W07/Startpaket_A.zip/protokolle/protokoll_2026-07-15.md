# Protokoll Vorstandssitzung vom 15.07.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir; als Gäste Paul Schröder und Emma Fischer
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Jonas Weber

## TOP 1: Rückblick Sommerfest

Etwa 45 Gäste. Die Kosten lagen mit 284 Euro unter dem Budget von 300 Euro.

## TOP 2: Übergabe Ressort Events

Paul Schröder gibt die Ressortleitung Events zum Ende des Sommersemesters ab. Der Vorstand benennt Emma Fischer als Ressortleitung Events ab dem Wintersemester 2026/27. Paul unterstützt bei der Einarbeitung.

## TOP 3: Finanzstand

Aylin Demir berichtet: Vom Semesterbudget wurden 1.912 Euro ausgegeben. Der Rest verfällt nicht, sondern geht in die Rücklage.
