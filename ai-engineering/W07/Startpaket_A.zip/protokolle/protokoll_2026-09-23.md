# Protokoll Vorstandssitzung vom 23.09.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir; als Gast Emma Fischer
- **Sitzungsleitung:** Lena Hofmann
- **Protokoll:** Aylin Demir

## TOP 1: Planung Wintersemester 2026/27

Der Infoabend für Erstsemester findet am 28. Oktober 2026 statt, die Mitgliederversammlung am 11. November 2026. Emma Fischer übernimmt die Organisation des Infoabends.

## TOP 2: Hackathon

Raumanfrage beim Gründerzentrum läuft. Lindqvist Robotics stellt einen Datensatz und eine Jury-Person. Die Zustimmung der Mitgliederversammlung zum Budget steht noch aus.

## TOP 3: Workshops

Sara Lindner bietet im Wintersemester zwei Workshops an: Git und GitHub (5. November) und SQL für Datenanalyse (20. Januar).
