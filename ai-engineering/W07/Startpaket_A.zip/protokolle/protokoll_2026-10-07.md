# Protokoll Vorstandssitzung vom 07.10.2026

Datenfabrik Karlsruhe e.V. · fiktives Schulungsdokument

- **Ort:** Raum 1.07, Gebäude 20.21
- **Anwesend:** Lena Hofmann, Jonas Weber, Aylin Demir
- **Sitzungsleitung:** Jonas Weber
- **Protokoll:** Lena Hofmann

## TOP 1: Einladung zur Mitgliederversammlung

Die Einladung zur Mitgliederversammlung am 11. November muss nach § 9 spätestens zwei Wochen vorher verschickt werden. Lena Hofmann verschickt sie am 21. Oktober per E-Mail. Tagesordnung: Bericht, Budget Wintersemester, Zustimmung Hackathon-Budget, Verschiedenes.

## TOP 2: Budgetvorschlag Wintersemester

Aylin Demir schlägt ein Semesterbudget von 3.100 Euro vor, davon 1.400 Euro für den Hackathon, 700 Euro für Events, 400 Euro für Exkursionen, 300 Euro für Öffentlichkeitsarbeit, 150 Euro für IT und 150 Euro Reserve. Der Vorschlag wird der Mitgliederversammlung vorgelegt.

## TOP 3: Neue Mitglieder

Vier Aufnahmeanträge liegen vor. Beschluss: Alle vier werden aufgenommen. Jonas Weber versendet die Begrüßungsmails.
