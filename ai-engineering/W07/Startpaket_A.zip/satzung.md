# Satzung der Datenfabrik Karlsruhe e.V.

Fassung vom 14. Januar 2026 · Dieses Dokument ist fiktiv und dient ausschließlich Schulungszwecken.

## § 1 Name, Sitz, Geschäftsjahr

(1) Der Verein führt den Namen „Datenfabrik Karlsruhe“. Er ist in das Vereinsregister eingetragen und führt den Zusatz „e.V.“.

(2) Sitz des Vereins ist Karlsruhe.

(3) Das Geschäftsjahr beginnt am 1. Oktober und endet am 30. September des folgenden Jahres.

## § 2 Zweck des Vereins

(1) Zweck des Vereins ist die Förderung von Bildung und Wissenschaft auf den Gebieten Data Science, künstliche Intelligenz und digitale Produktion.

(2) Der Satzungszweck wird insbesondere verwirklicht durch Workshops und Vorträge für Studierende, Exkursionen zu Unternehmen und Forschungseinrichtungen, studentische Projekte sowie die Vernetzung von Studierenden mit Wissenschaft und Praxis.

## § 3 Gemeinnützigkeit

(1) Der Verein verfolgt ausschließlich und unmittelbar gemeinnützige Zwecke im Sinne des Abschnitts „Steuerbegünstigte Zwecke“ der Abgabenordnung. Er ist selbstlos tätig und verfolgt nicht in erster Linie eigenwirtschaftliche Zwecke.

(2) Mittel des Vereins dürfen nur für die satzungsmäßigen Zwecke verwendet werden. Die Mitglieder erhalten keine Zuwendungen aus Mitteln des Vereins. Ehrenamtlich Tätige können Auslagen gegen Beleg erstattet bekommen.

## § 4 Mitgliedschaft

(1) Ordentliches Mitglied kann jede Person werden, die an einer Karlsruher Hochschule immatrikuliert ist.

(2) Fördermitglied kann jede natürliche oder juristische Person werden, die den Zweck des Vereins unterstützen möchte. Fördermitglieder haben in der Mitgliederversammlung Rede-, aber kein Stimmrecht.

(3) Ordentliche Mitglieder, die ihr Studium beenden, werden mit Ende des Semesters, in dem sie exmatrikuliert werden, zu Alumni-Mitgliedern. Alumni-Mitglieder haben dieselben Rechte wie Fördermitglieder.

## § 5 Erwerb der Mitgliedschaft

(1) Die Aufnahme ist in Textform beim Vorstand zu beantragen. Das Online-Formular auf der Vereinswebsite genügt.

(2) Über die Aufnahme entscheidet der Vorstand innerhalb von vier Wochen. Eine Ablehnung muss nicht begründet werden.

## § 6 Beendigung der Mitgliedschaft

(1) Die Mitgliedschaft endet durch Austritt, Ausschluss oder Tod.

(2) Der Austritt ist in Textform gegenüber dem Vorstand zu erklären. Er ist mit einer Frist von vier Wochen zum Ende eines Semesters möglich.

(3) Ein Mitglied kann durch Beschluss des Vorstands ausgeschlossen werden, wenn es in grober Weise gegen die Interessen des Vereins verstößt oder mit dem Beitrag für mehr als zwei Semester im Rückstand ist. Vor dem Beschluss ist dem Mitglied Gelegenheit zur Stellungnahme zu geben. Gegen den Ausschluss kann das Mitglied innerhalb eines Monats die Mitgliederversammlung anrufen.

## § 7 Mitgliedsbeiträge

(1) Von den Mitgliedern werden Beiträge erhoben. Höhe und Fälligkeit regelt die Beitragsordnung, die von der Mitgliederversammlung beschlossen wird.

(2) Der Vorstand kann Beiträge in begründeten Fällen ermäßigen oder erlassen.

## § 8 Organe des Vereins

Organe des Vereins sind die Mitgliederversammlung und der Vorstand.

## § 9 Mitgliederversammlung

(1) Die ordentliche Mitgliederversammlung findet einmal in jedem Semester statt, in der Regel in den ersten sechs Wochen der Vorlesungszeit.

(2) Der Vorstand lädt mindestens zwei Wochen vorher in Textform, insbesondere per E-Mail an die zuletzt bekannte Adresse, unter Angabe der Tagesordnung ein.

(3) Eine außerordentliche Mitgliederversammlung ist einzuberufen, wenn der Vorstand dies beschließt oder ein Viertel der ordentlichen Mitglieder es unter Angabe von Gründen verlangt.

(4) Die Mitgliederversammlung ist beschlussfähig, wenn sie ordnungsgemäß einberufen wurde. Beschlüsse werden mit einfacher Mehrheit der abgegebenen Stimmen gefasst. Enthaltungen zählen nicht. Satzungsänderungen und die Auflösung des Vereins erfordern eine Mehrheit von zwei Dritteln der abgegebenen Stimmen.

(5) Die Mitgliederversammlung ist insbesondere zuständig für die Wahl und Entlastung des Vorstands, die Wahl der Kassenprüfer, die Beitragsordnung, Satzungsänderungen und die Auflösung des Vereins.

(6) Über die Mitgliederversammlung ist ein Protokoll anzufertigen, das von der Versammlungsleitung und der protokollführenden Person zu unterzeichnen ist.

## § 10 Vorstand

(1) Der Vorstand besteht aus der oder dem ersten Vorsitzenden, der oder dem zweiten Vorsitzenden und der Finanzvorständin oder dem Finanzvorstand.

(2) Der Verein wird gerichtlich und außergerichtlich durch zwei Vorstandsmitglieder gemeinsam vertreten.

(3) Der Vorstand wird von der Mitgliederversammlung für die Dauer von einem Jahr gewählt. Er bleibt bis zur Wahl eines neuen Vorstands im Amt. Wiederwahl ist zulässig.

(4) Der Vorstand tagt in der Regel alle zwei Wochen während der Vorlesungszeit. Er ist beschlussfähig, wenn mindestens zwei Mitglieder anwesend sind.

(5) Ausgaben über 250 Euro, die nicht im beschlossenen Semesterbudget enthalten sind, bedürfen eines Vorstandsbeschlusses. Ausgaben über 1.000 Euro bedürfen zusätzlich der Zustimmung der Mitgliederversammlung.

## § 11 Kassenprüfung

(1) Die Mitgliederversammlung wählt für die Dauer von einem Jahr zwei Kassenprüferinnen oder Kassenprüfer, die nicht dem Vorstand angehören dürfen.

(2) Die Kassenprüfer prüfen die Kassenführung einmal im Geschäftsjahr und berichten der Mitgliederversammlung.

## § 12 Ressorts und Projekte

(1) Zur Organisation seiner Arbeit kann der Vorstand Ressorts einrichten, insbesondere für Events, Unternehmenskontakte, Öffentlichkeitsarbeit und IT.

(2) Jedes Ressort wird von einer Ressortleitung geführt, die der Vorstand für ein Semester benennt.

(3) Projekte mit einem Budget über 500 Euro benötigen eine verantwortliche Projektleitung und einen kurzen schriftlichen Projektplan.

## § 13 Engagementbescheinigungen

(1) Mitglieder erhalten auf Antrag eine Bescheinigung über ihr ehrenamtliches Engagement im Verein.

(2) Voraussetzung ist eine aktive Mitarbeit über mindestens zwei Semester oder ein dokumentierter Umfang von mindestens 40 Stunden.

(3) Die Bescheinigung nennt Zeitraum, Funktionen und wesentliche Tätigkeiten. Sie wird vom Vorstand innerhalb von vier Wochen nach Antrag ausgestellt und von zwei Vorstandsmitgliedern unterzeichnet.

## § 14 Datenschutz

(1) Der Verein verarbeitet personenbezogene Daten seiner Mitglieder nur, soweit dies für die Mitgliederverwaltung und die Vereinsarbeit erforderlich ist.

(2) Mitgliederlisten werden nicht an Dritte weitergegeben. Unternehmenspartner erhalten Kontaktdaten nur mit ausdrücklicher Einwilligung des jeweiligen Mitglieds.

## § 15 Auflösung des Vereins

(1) Die Auflösung kann nur in einer Mitgliederversammlung mit einer Mehrheit von zwei Dritteln der abgegebenen Stimmen beschlossen werden.

(2) Bei Auflösung oder Wegfall steuerbegünstigter Zwecke fällt das Vermögen an eine juristische Person des öffentlichen Rechts oder eine andere steuerbegünstigte Körperschaft zur Verwendung für die Förderung von Bildung und Wissenschaft.

## Anlage: Beitragsordnung

Beschlossen von der Mitgliederversammlung am 14. Januar 2026.

| Mitgliedsart | Beitrag | Fälligkeit |
|---|---|---|
| Ordentliches Mitglied | 10 Euro pro Semester | zu Beginn der Vorlesungszeit |
| Fördermitglied, natürliche Person | 50 Euro pro Jahr | 1. Oktober |
| Fördermitglied, Unternehmen | 500 Euro pro Jahr | 1. Oktober |
| Alumni-Mitglied | 20 Euro pro Jahr | 1. Oktober |

Mitglieder in der ersten Vorlesungszeit nach ihrem Eintritt zahlen keinen Beitrag.
