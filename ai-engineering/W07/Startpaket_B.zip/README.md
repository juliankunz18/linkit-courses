# Startpaket Track B: Instandhaltungs-Assistent Nordwerk GmbH

Alle Daten sind **erfunden**. Die Nordwerk GmbH, ihre Maschinen und Beschäftigten gibt es nicht.

| Datei | Inhalt | Wofür im Projekt |
|---|---|---|
| `wartungshandbuch.md` | Wartungshandbuch (Auszug, ca. 10 Seiten): Zuständigkeiten, Sicherheit, Betriebsstoffe, 8 Maschinen, Ersatzteile, Fehlercodes | Wissensbasis (RAG, Woche 7) |
| `maschinen.csv` | Stammdaten der 8 Maschinen mit Status, Betriebsstunden, letzter Wartung | Tool „Maschinenstatus prüfen“ (Woche 8) |
| `stoerungen.csv` | 24 Störungstickets vom 5. bis 16. Oktober 2026 mit Priorität und Status | Tool „Tickets suchen und anlegen“ (Woche 8) |
| `schichtbuch.csv` | 30 Schichtbucheinträge im selben Zeitraum | Tool oder Wissensbasis für „Schichtbuch zusammenfassen“ |

## Beispielfragen zum Start

- Wie oft muss das Spindellager der Drehmaschine nachgeschmiert werden? *(Handbuch 3.3: alle 500 Betriebsstunden)*
- Was bedeutet Fehler E33 an der Schweißstromquelle? *(Handbuch 5.1: Drahtvorschub blockiert)*
- Welche Tickets zu M-03 sind noch offen? *(stoerungen.csv, braucht ein Tool)*
- Lege ein Ticket an: Lichtschranke an M-06 verschmutzt, Priorität niedrig. *(schreibendes Tool mit Bestätigung, Woche 8)*
- Was kostet ein neuer Spindellagersatz? *(steht nirgends, der Assistent soll das sagen)*

Das Wartungshandbuch ist dasselbe wie im Notebook der Woche 7. Dort seht ihr, wie es gechunkt und durchsucht wird.
