# Wartungshandbuch Nordwerk GmbH, Werk Karlsruhe (Auszug)

Dokument WH-2026-03 · Stand: September 2026 · Herausgeber: Abteilung Instandhaltung · Dieses Dokument ist fiktiv und dient ausschließlich Schulungszwecken.

## 1 Allgemeines

### 1.1 Geltungsbereich und Aufbau

Dieses Handbuch gilt für alle Fertigungs- und Prüfanlagen in den Hallen 1 und 2 des Werks Karlsruhe. Es richtet sich an Maschinenbedienerinnen und -bediener, Schichtleitungen und das Instandhaltungsteam. Kapitel 1 regelt Zuständigkeiten, Sicherheit und Dokumentation. Kapitel 2 beschreibt Betriebsstoffe, die an mehreren Maschinen verwendet werden. Kapitel 3 enthält für jede Maschine eine Kurzbeschreibung, die Wartungsintervalle, typische Störungen und wichtige Ersatzteile. Kapitel 4 regelt das Ersatzteillager, Kapitel 5 enthält Fehlercodes und Kontakte.

Die Herstellerdokumentation der einzelnen Maschinen bleibt verbindlich. Bei Widersprüchen gilt die Herstellerangabe, und die Instandhaltung ist zu informieren, damit dieses Handbuch angepasst werden kann. Änderungen am Handbuch gibt die Leitung Instandhaltung frei. Die jeweils gültige Fassung liegt im Intranet. Ausgedruckte Exemplare an den Maschinen sind nach jeder Änderung auszutauschen.

### 1.2 Zuständigkeiten und Eskalation

Für die tägliche Pflege und die Sichtprüfungen ist die Bedienerin oder der Bediener der Maschine zuständig. Wartungsarbeiten mit Werkzeug, das Öffnen von Schaltschränken und alle Arbeiten an Hydraulik, Druckluftverteilung und Elektrik führt ausschließlich das Instandhaltungsteam durch.

Bei einer Störung meldet die Bedienerin oder der Bediener zunächst an die Schichtleitung. Die Schichtleitung entscheidet über die Priorität und informiert die Instandhaltung. Während der Kernzeit von 6:00 bis 22:00 Uhr ist die Instandhaltung über die Leitstelle erreichbar. Außerhalb der Kernzeit, an Wochenenden und an Feiertagen ist bei Störungen mit hoher Priorität die Rufbereitschaft der Instandhaltung unter der internen Nummer 4711 anzurufen. Bei Störungen mit mittlerer oder niedriger Priorität genügt außerhalb der Kernzeit ein Ticket, das am nächsten Arbeitstag bearbeitet wird.

Kann die Instandhaltung eine Störung nicht innerhalb von vier Stunden beheben, informiert sie die Produktionsleitung und entscheidet gemeinsam mit ihr, ob ein externer Servicepartner beauftragt wird. Die Kontakte der Servicepartner stehen in Kapitel 5.2.

### 1.3 Arbeitssicherheit

Vor jeder Wartung, Reinigung oder Störungsbehebung im Gefahrenbereich einer Maschine ist die Maschine freizuschalten. Das Vorgehen folgt immer denselben fünf Schritten: Maschine stillsetzen, Hauptschalter ausschalten, Hauptschalter mit persönlichem Vorhängeschloss gegen Wiedereinschalten sichern, Spannungsfreiheit und Druckfreiheit prüfen, Arbeitsbereich kennzeichnen. Jede Person, die im Gefahrenbereich arbeitet, hängt ihr eigenes Schloss an. Die Maschine darf erst wieder eingeschaltet werden, wenn alle Schlösser entfernt sind.

Arbeiten an Hydraulikanlagen sind nur im drucklosen Zustand erlaubt. Druckspeicher müssen vorher entladen werden, der Manometerwert muss null zeigen. Arbeiten in der Roboter-Schweißzelle erfolgen grundsätzlich zu zweit, eine Person bleibt außerhalb der Zelle und hat Zugriff auf den Not-Aus. Beim Umgang mit Kühlschmierstoff sind Schutzhandschuhe aus Nitril und eine Schutzbrille zu tragen. Hautschutzplan und Betriebsanweisung hängen an jeder Maschine mit Kühlschmierstoff aus.

Defekte Schutzeinrichtungen wie Türschalter, Lichtgitter oder Not-Aus-Taster dürfen niemals überbrückt werden. Ist eine Schutzeinrichtung defekt, bleibt die Maschine außer Betrieb, bis die Instandhaltung sie instand gesetzt und geprüft hat.

### 1.4 Dokumentation von Störungen und Wartungen

Jede Störung wird als Ticket im Instandhaltungssystem erfasst. Störungen mit hoher Priorität sind innerhalb von 30 Minuten nach Feststellung als Ticket anzulegen, alle anderen bis zum Ende der Schicht. Das Ticket enthält Maschine, Zeitpunkt, Beschreibung, vermutete Ursache, Priorität und Stillstandszeit.

Für die Priorität gelten im ganzen Werk dieselben Definitionen. Hoch bedeutet: Die Maschine steht oder es besteht ein Sicherheitsrisiko. Mittel bedeutet: Die Maschine läuft eingeschränkt, Qualität oder Tempo leiden. Niedrig bedeutet: kein Einfluss auf die laufende Produktion.

Durchgeführte Wartungen werden mit Datum, Tätigkeit, verbrauchten Ersatzteilen und Namen im Wartungsplan der Maschine eingetragen. Bei Abweichungen vom Sollzustand, etwa ungewöhnlichem Verschleiß, ist zusätzlich ein Hinweis-Ticket anzulegen, damit die Intervalle überprüft werden können.

## 2 Betriebsstoffe

### 2.1 Schmierstoffe und Öle

Im Werk werden nur die folgenden freigegebenen Betriebsstoffe verwendet. Andere Produkte dürfen nur nach Freigabe durch die Instandhaltung eingesetzt werden, weil falsche Schmierstoffe Dichtungen angreifen und Lager schädigen können.

| Anwendung | Bezeichnung | Gebinde | Lagerort |
|---|---|---|---|
| Hydraulikaggregate aller Maschinen | Hydrauliköl HLP 46 | 20-Liter-Kanister | Gefahrstofflager, Regal G-2 |
| Spindellager der Drehmaschine | Wälzlagerfett NW-LX2 | 400-Gramm-Kartusche | Ersatzteillager, Regal C-04 |
| Führungsbahnen der Fräszentren | Gleitbahnöl CGLP 68 | 20-Liter-Kanister | Gefahrstofflager, Regal G-3 |
| Zentralschmierung der Montagelinie | Kettenöl NW-K100 | 5-Liter-Kanister | Gefahrstofflager, Regal G-3 |
| Kühlschmierstoff aller Zerspanungsmaschinen | Emulsion NW-Cut 300 (Konzentrat) | 200-Liter-Fass | Gefahrstofflager, Bereich G-1 |

Leere Gebinde und Altöl werden in den gekennzeichneten Sammelbehältern im Gefahrstofflager entsorgt. Ölgetränkte Putzlappen gehören in die roten Sicherheitsbehälter an den Maschinen.

### 2.2 Pflege des Kühlschmierstoffs

Die Fräszentren, die Drehmaschine und die Rundschleifmaschine arbeiten mit der wassergemischten Emulsion NW-Cut 300. Ein gut gepflegter Kühlschmierstoff verlängert die Standzeit der Werkzeuge, verbessert die Oberflächengüte und schützt die Haut der Beschäftigten.

Die Konzentration soll zwischen 6 bis 8 Prozent liegen. Sie wird einmal pro Woche mit dem Refraktometer gemessen, der Messwert wird mit dem Faktor 1,1 multipliziert (Refraktometerfaktor des Konzentrats). Der pH-Wert soll zwischen 8,5 und 9,3 liegen, der Nitritgehalt unter 20 mg/l. Alle drei Werte werden im Kühlschmierstoff-Protokoll an der Maschine eingetragen.

Ist die Konzentration zu niedrig, wird Konzentrat über das Mischgerät nachdosiert, nie unverdünnt in den Tank gegeben. Ist sie zu hoch, wird mit Wasser nachgefüllt. Schäumt der Kühlschmierstoff stark, ist zuerst der Füllstand zu prüfen, denn zu wenig Flüssigkeit im Tank führt zu Luftansaugung an der Pumpe. Hilft das nicht, wird nach Rücksprache mit der Instandhaltung Entschäumer NW-AF 2 in einer Dosierung von 0,05 Prozent zugegeben. Riecht der Kühlschmierstoff faulig oder liegt der pH-Wert unter 8,0, ist er biologisch belastet und muss gewechselt werden. Unabhängig davon wird der Kühlschmierstoff spätestens alle sechs Monate vollständig gewechselt, einschließlich Reinigung des Tanks.

### 2.3 Druckluft

Die zentrale Druckluftversorgung liefert einen Netzdruck von 6 bar. An jeder Maschine sitzt eine Wartungseinheit aus Filter, Druckregler und Wasserabscheider. Der Wasserabscheider wird täglich zu Schichtbeginn entleert, sofern er keinen automatischen Ablass hat. Das Filterelement wird halbjährlich gewechselt oder früher, wenn die Differenzdruckanzeige rot zeigt.

Fällt der Druck an einer Maschine unter 5,5 bar, schaltet die Maschinensteuerung in den meisten Fällen mit einer Warnung ab. Druckschwankungen haben häufig eine von drei Ursachen: ein verschmutztes Filterelement, eine Leckage an Schläuchen oder Kupplungen oder ein zu hoher gleichzeitiger Verbrauch in der Halle. Leckagen lassen sich mit Lecksuchspray finden. Undichte Kupplungen werden getauscht, nicht abgedichtet.

## 3 Maschinen

### 3.1 M-01 CNC-Fräszentrum 1

#### Kurzbeschreibung

Das CNC-Fräszentrum 1 ist ein vertikales Bearbeitungszentrum vom Typ Kessler KFZ 800, Baujahr 2018, Standort Halle 1, Platz 4. Es bearbeitet vor allem Gehäuseteile aus Aluminium. Die Arbeitsspindel erreicht 12.000 Umdrehungen pro Minute. Das Werkzeugmagazin hat 24 Plätze. Verfahrwege: X 800 mm, Y 500 mm, Z 500 mm.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Späne aus dem Arbeitsraum entfernen, Sichtfenster reinigen | täglich | Bedienung |
| Füllstand Gleitbahnöl prüfen | täglich | Bedienung |
| Kühlschmierstoff messen (Kapitel 2.2) | wöchentlich | Bedienung |
| Abstreifer der Führungsbahnen prüfen | monatlich | Instandhaltung |
| Spindelrundlauf mit Prüfdorn messen, Grenzwert 5 µm | alle 1.000 Betriebsstunden | Instandhaltung |
| Hydrauliköl wechseln, Filter tauschen | jährlich | Instandhaltung |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Achsantrieb meldet Überstrom | Schwergängige Führung, Späne unter dem Abstreifer, Motor defekt | Maschine freischalten, Abstreifer reinigen; tritt der Fehler erneut auf, Instandhaltung rufen |
| Kühlmittel tropft aus Leitung | Schlauchschelle locker, Schlauch porös | Auffangwanne unterstellen, Ticket mit Priorität niedrig, Schlauch beim nächsten Stillstand tauschen |
| CNC-Programm lässt sich nicht laden | Programm fehlerhaft übertragen, Speicher voll | Programm erneut aus der Programmverwaltung laden, alte Programme archivieren |

#### Wichtige Ersatzteile

| Teil | Teilenummer | Lagerort |
|---|---|---|
| Abstreifer Führungsbahn X | KFZ-8810 | Regal A-03 |
| Kühlmittelschlauch 12 mm, Meterware | NW-SL12 | Regal A-07 |

### 3.2 M-02 CNC-Fräszentrum 2

#### Kurzbeschreibung

Das CNC-Fräszentrum 2 ist baugleich zum Fräszentrum 1, jedoch vom neueren Typ Kessler KFZ 800 plus, Baujahr 2021, Standort Halle 1, Platz 5. Unterschiede: Das Werkzeugmagazin hat 40 Plätze statt 24, und die Maschine besitzt einen Messtaster zur automatischen Werkstückvermessung. Es fertigt vorwiegend Teile aus Stahl.

#### Wartungsintervalle

Es gelten dieselben Intervalle wie bei M-01. Zusätzlich gilt:

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Greifer des Werkzeugwechslers reinigen und auf Verschleiß prüfen | monatlich | Instandhaltung |
| Messtaster kalibrieren | vierteljährlich | Instandhaltung |
| Kugelgewindetriebe auf Spiel prüfen | alle 2.000 Betriebsstunden | Instandhaltung |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Werkzeugwechsler hakt, Wechsel dauert deutlich länger | Verschmutzte Greiferfinger, verschlissene Federn | Greifer reinigen; bei Verschleiß Federn tauschen (Teilenummer KFZ-9120) |
| Quietschen an einer Achse | Schmierung der Führung unzureichend | Zentralschmierung manuell auslösen, Gleitbahnöl-Füllstand prüfen; Geräusch weiter beobachten |
| Messtaster liefert stark streuende Werte | Tastkugel verschmutzt, Kalibrierung veraltet | Tastkugel reinigen, Messtaster neu kalibrieren |

### 3.3 M-03 CNC-Drehmaschine

#### Kurzbeschreibung

Die CNC-Drehmaschine ist eine Schrägbettmaschine vom Typ Hartwig TD 400, Baujahr 2015, Standort Halle 1, Platz 9. Sie fertigt Wellen und Bolzen bis 400 mm Länge. Das Hydraulikaggregat versorgt das Spannfutter und den Reitstock. Wegen ihres Alters ist sie die störanfälligste Maschine in Halle 1.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Späne entfernen, Spannfutter abblasen | täglich | Bedienung |
| Ölstand im Hydraulikaggregat prüfen (Hydrauliköl HLP 46) | täglich | Bedienung |
| Spindellager mit Wälzlagerfett NW-LX2 nachschmieren, Menge 8 Gramm je Lager | alle 500 Betriebsstunden | Instandhaltung |
| Spannfutter zerlegen, reinigen, Backen fetten | alle 250 Betriebsstunden | Instandhaltung |
| Spindelrundlauf messen, Grenzwert 8 µm | alle 1.000 Betriebsstunden | Instandhaltung |
| Hydrauliköl wechseln, Rücklauffilter tauschen | jährlich | Instandhaltung |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Spindel vibriert, Teile außerhalb der Toleranz | Spindellager verschlissen oder unzureichend geschmiert | Drehzahl reduzieren, Instandhaltung informieren; Rundlauf messen, Lager nachschmieren oder tauschen |
| Maschine schaltet mit Meldung „Hydraulikdruck“ ab | Ölstand unter Minimum, Leckage | Ölstand prüfen; nur mit HLP 46 auffüllen; Leckage suchen, Ticket mit Priorität hoch |
| Spannfutter spannt ungleichmäßig | Späne in der Backenführung | Spannfutter reinigen; bei Wiederholung zerlegen |

#### Wichtige Ersatzteile

| Teil | Teilenummer | Lagerort |
|---|---|---|
| Ersatz-Spannfutter dreibackig, 250 mm | HTD-2250 | Regal C-12 |
| Spindellagersatz | HTD-1100 | Regal C-11 |
| Rücklauffilter Hydraulik | HTD-3310 | Regal C-04 |

### 3.4 M-04 Rundschleifmaschine

#### Kurzbeschreibung

Die Rundschleifmaschine vom Typ Brenner RS 600, Baujahr 2019, Standort Halle 2, Platz 2, schleift gehärtete Wellen auf das Endmaß. Die Schleifscheibe hat einen Durchmesser von 500 mm. Der Kühlschmierstoff wird über ein Papierbandfilter gereinigt.

#### Sicherheitshinweise zur Schleifscheibe

Schleifscheiben sind bruchgefährdet. Eine neue Schleifscheibe wird vor der Montage durch eine Klangprobe geprüft: Die Scheibe wird frei hängend mit einem Holzhammer leicht angeschlagen. Ein heller, klarer Klang zeigt eine unbeschädigte Scheibe, ein dumpfer oder scheppernder Klang deutet auf Risse hin. Scheiben mit Rissen oder unklarer Klangprobe dürfen nicht montiert werden. Die zulässige Umfangsgeschwindigkeit der eingesetzten Scheiben beträgt höchstens 50 m/s. Nach jeder Montage wird die Scheibe ausgewuchtet und abgerichtet, anschließend läuft sie mindestens fünf Minuten mit Betriebsdrehzahl, während sich niemand in der Drehebene aufhält.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Schleifscheibe abrichten | je nach Bedarf, spätestens alle 50 Werkstücke | Bedienung |
| Papierbandfilter prüfen, Rolle wechseln | wenn die Füllstandsanzeige gelb zeigt | Bedienung |
| Kühlschmierstoff messen (Kapitel 2.2) | wöchentlich | Bedienung |
| Wuchteinrichtung prüfen | monatlich | Instandhaltung |
| Schleifspindel auf Lagergeräusche prüfen | vierteljährlich | Instandhaltung |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Risse an der Schleifscheibe | Schlag, Überlastung, falsche Lagerung | Maschine sofort stoppen und freischalten, Scheibe tauschen, Ticket mit Priorität hoch |
| Rattermarken auf dem Werkstück | Scheibe unwuchtig oder stumpf | Scheibe auswuchten und abrichten |
| Englische Bedienoberfläche nach Update | Spracheinstellung zurückgesetzt | Im Menü Einstellungen, Sprache auf Deutsch stellen; kein Einfluss auf die Produktion |

### 3.5 M-05 Roboter-Schweißzelle

#### Kurzbeschreibung

Die Roboter-Schweißzelle besteht aus einem Sechsachs-Roboter, der Schweißstromquelle Varion 500, einem Drehtisch mit zwei hydraulischen Spannvorrichtungen und einem Lichtgitter an der Beladeseite. Baujahr 2020, Standort Halle 2, Platz 6. Geschweißt wird im MAG-Verfahren mit Mischgas.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Brenner reinigen, Gasdüse und Kontaktrohr prüfen | alle vier Stunden Schweißbetrieb | Bedienung |
| Lichtgitter mit Prüfstab testen | täglich zu Schichtbeginn | Bedienung |
| Schutzgasflasche wechseln | wenn der Flaschendruck unter 10 bar fällt | Bedienung |
| Kühlflüssigkeit des Brenners prüfen | wöchentlich | Bedienung |
| Hydraulik der Spannvorrichtungen auf Leckagen prüfen | monatlich | Instandhaltung |
| Roboter-Getriebeöl wechseln | alle 20.000 Betriebsstunden | Servicepartner |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Schweißstromquelle zeigt Fehlercode | siehe Kapitel 5.1 | Fehlercode ablesen und nach Tabelle vorgehen |
| Lichtgitter löst aus, obwohl sich niemand im Schutzfeld befindet | Verschmutzte Linsen, Schweißspritzer auf Sender oder Empfänger, verstellte Ausrichtung | Linsen mit weichem Tuch reinigen, Ausrichtung prüfen; Lichtgitter niemals überbrücken; bei Wiederholung Instandhaltung rufen |
| Spannvorrichtung öffnet sich während des Schweißens | Hydraulikdruck fällt ab, Leckage am Spannzylinder | Zelle sofort stillsetzen, Ticket mit Priorität hoch, Verletzungsgefahr |
| Bildschirm am Bedienpult flackert | Wackelkontakt im Displaykabel | Ticket mit Priorität niedrig, Bedienung bleibt möglich |

### 3.6 M-06 Montagelinie A

#### Kurzbeschreibung

Die Montagelinie A verbindet sechs Montagestationen über ein Werkstückträger-Fördersystem. Gesteuert wird sie von einer zentralen SPS, die über das Werksnetz mit dem Leitrechner der Produktion verbunden ist. Lichtschranken an der Zuführung erkennen die Werkstückträger. Baujahr 2017, Umbau 2023, Standort Halle 2, Bereich M.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Lichtschranken an Zuführung und Stationen reinigen | täglich | Bedienung |
| Not-Aus-Taster aller Stationen auf Funktion prüfen | wöchentlich | Schichtleitung |
| Kettenspannung des Fördersystems prüfen | monatlich | Instandhaltung |
| Zentralschmierung auffüllen (Kettenöl NW-K100) | wenn die Anzeige rot zeigt | Instandhaltung |
| Datensicherung der SPS | nach jeder Programmänderung, mindestens vierteljährlich | Instandhaltung |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Not-Aus lässt sich nicht zurücksetzen | Taster mechanisch verklemmt, Fehler im Sicherheitskreis | Alle Not-Aus-Taster der Linie prüfen; bleibt der Fehler, Instandhaltung rufen; Linie steht, Priorität hoch |
| SPS verliert die Verbindung zum Leitrechner | Netzwerkkabel, Switch, IP-Konflikt | Linkanzeige am Switch prüfen; Neustart der SPS nur durch die Instandhaltung |
| Kurze Unterbrechungen durch Lichtschranke | Staub auf der Optik | Lichtschranke reinigen, bei Wiederholung Ausrichtung prüfen |

### 3.7 M-07 Prüfstand

#### Kurzbeschreibung

Der Prüfstand prüft fertig montierte Baugruppen auf Dichtheit und Funktion. Er besteht aus einer Druckprüfeinheit mit Druckluft, einem Messrechner mit Prüfsoftware und einem Etikettendrucker. Baujahr 2022, Standort Halle 2, Bereich P. Die Messergebnisse werden automatisch auf dem Qualitätsserver gespeichert.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Prüfadapter und Dichtungen auf Beschädigung prüfen | täglich | Bedienung |
| Leckprüfung mit Referenzteil | zu jedem Schichtbeginn | Bedienung |
| Kalibrierung der Drucksensoren | jährlich durch einen akkreditierten Dienstleister | Qualitätssicherung |
| Elektrische Prüfung nach DGUV Vorschrift 3 | jährlich | Elektrofachkraft |
| Datensicherung des Messrechners prüfen | monatlich | IT |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Messprotokolle werden nicht gespeichert | Verbindung zum Qualitätsserver gestört, Speicher voll | Werte von Hand im Ersatzprotokoll notieren, IT informieren, Priorität mittel |
| Messungen streuen, Referenzteil fällt durch | Druckluft schwankt, Dichtung am Adapter verschlissen | Netzdruck an der Wartungseinheit prüfen (Kapitel 2.3), Dichtung tauschen |
| Prüfplakette abgelaufen | Prüftermin verpasst | Elektrofachkraft informieren, Prüfung nachholen |

### 3.8 M-08 Teilewaschanlage

#### Kurzbeschreibung

Die Teilewaschanlage reinigt Teile nach der Zerspanung von Spänen und Kühlschmierstoff. Sie arbeitet mit wässriger, alkalischer Waschlauge bei 60 °C, die über einen elektrischen Heizstab erwärmt wird. Ein Förderband transportiert die Teilekörbe durch Wasch-, Spül- und Trockenzone. Baujahr 2016, Standort Halle 1, Platz 12.

#### Wartungsintervalle

| Tätigkeit | Intervall | Zuständig |
|---|---|---|
| Siebe in der Waschzone reinigen | täglich | Bedienung |
| Temperatur und Füllstand der Waschlauge prüfen | täglich | Bedienung |
| Ölabscheider leeren | wöchentlich | Bedienung |
| Waschbad komplett wechseln, Tank reinigen | alle vier Wochen | Instandhaltung |
| Förderband auf Spannung und Verschleiß prüfen | monatlich | Instandhaltung |
| Heizstab entkalken | halbjährlich | Instandhaltung |

#### Typische Störungen

| Symptom | Mögliche Ursache | Maßnahme |
|---|---|---|
| Teile bleiben fettig | Waschlauge zu kalt oder verbraucht | Temperatur prüfen; liegt sie deutlich unter 60 °C, Heizstab und Sicherung prüfen lassen; Bad wechseln, wenn es älter als vier Wochen ist |
| Förderband steht | Band gerissen oder Antrieb blockiert | Anlage freischalten, Ursache prüfen, Priorität hoch |
| Waschzyklen zu kurz nach Stromausfall | Zeitsteuerung auf Werkseinstellung zurückgesetzt | Parameter aus der Parameterliste im Schaltschrank neu eingeben |

## 4 Ersatzteillager und Bestellung

Das Ersatzteillager befindet sich in Halle 2 neben der Werkstatt der Instandhaltung. Die Regale sind nach Maschinen gruppiert: Regalreihe A für die Fräszentren, B für die Schleifmaschine, C für die Drehmaschine, D für die Schweißzelle, E für Montagelinie und Prüfstand, F für die Waschanlage. Gefahrstoffe lagern getrennt im Gefahrstofflager.

Für kritische Teile gelten Mindestbestände. Wird ein Teil entnommen, trägt die entnehmende Person die Entnahme in die Lagerliste ein. Fällt der Bestand unter den Mindestbestand, bestellt die Instandhaltung über den Einkauf nach. Bestellungen bis 500 Euro gibt die Leitung Instandhaltung frei, darüber die Werkleitung. Für Eilbestellungen bei Stillstand mit hoher Priorität darf die Rufbereitschaft auch außerhalb der Kernzeit direkt beim Servicepartner bestellen und dokumentiert dies am nächsten Arbeitstag.

| Teil | Mindestbestand | Übliche Lieferzeit |
|---|---|---|
| Schleifscheibe 500 mm für M-04 | 2 Stück | 3 Wochen |
| Spindellagersatz HTD-1100 für M-03 | 1 Satz | 6 Wochen |
| Kontaktrohre für den Schweißbrenner | 50 Stück | 1 Woche |
| Lichtschranke Zuführung M-06 | 1 Stück | 2 Wochen |

## 5 Anhang

### 5.1 Fehlercodes der Schweißstromquelle Varion 500

| Code | Bedeutung | Maßnahme |
|---|---|---|
| E10 | Netzspannung außerhalb des zulässigen Bereichs | Netzversorgung prüfen lassen |
| E21 | Übertemperatur im Kühlkreislauf des Brenners | Kühlflüssigkeit prüfen und auffüllen, Kühler auf Verschmutzung prüfen; Anlage abkühlen lassen |
| E33 | Drahtvorschub blockiert | Drahtführung und Vorschubrollen prüfen, Drahtspule auf Verwicklungen prüfen |
| E41 | Kein Gasdurchfluss | Flaschenventil und Druckminderer prüfen, Flasche bei unter 10 bar wechseln |
| E45 | Kommunikation zur Robotersteuerung unterbrochen | Steckverbindung des Buskabels prüfen, Instandhaltung rufen |

### 5.2 Kontakte

| Bereich | Kontakt |
|---|---|
| Leitstelle Instandhaltung (Kernzeit 6 bis 22 Uhr) | intern 4700 |
| Rufbereitschaft Instandhaltung (außerhalb der Kernzeit) | intern 4711 |
| IT-Service | intern 4800 |
| Servicepartner Fräszentren (Kessler Service) | Servicevertrag SV-1180, Hotline im Intranet |
| Servicepartner Schweißzelle | Servicevertrag SV-2045, Hotline im Intranet |
| Kalibrierdienstleister Prüfstand | Auftrag über die Qualitätssicherung |
