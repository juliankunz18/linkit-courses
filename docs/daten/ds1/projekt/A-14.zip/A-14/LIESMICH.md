# Datenpaket A-14 · Track A · Datenfabrik Karlsruhe e.V.

Erinnerungen und Anmeldegrenzen: wie plant die Hochschulgruppe ihre Veranstaltungen?

Die Datenfabrik Karlsruhe e.V. ist eine erfundene Hochschulgruppe. Sie lädt zu Vorträgen, Workshops, Stammtischen,
Exkursionen und Hackathons ein. Wer kommen will, meldet sich vorher an. Bisher nimmt der Verein höchstens so viele
Anmeldungen an, wie Plätze da sind, und bestellt Catering für alle Angemeldeten. Oft bleiben Plätze leer.

Im Sommersemester 2026 (ab 20. April) lief ein Versuch: Jede Anmeldung bekam per Münzwurf am Vorabend eine Erinnerung
oder nicht. Der Vorstand fragt:

1. Soll künftig jede angemeldete Person eine Erinnerung bekommen?
2. Wie viele Anmeldungen kann der Verein je Raumgröße annehmen, ohne dass zu oft mehr Leute kommen, als Plätze da sind?

Vorlesungszeiten: Wintersemester 2024/25 vom 14. Oktober 2024 bis 14. Februar 2025, Sommersemester 2025 vom 22. April
bis 25. Juli 2025, Wintersemester 2025/26 vom 20. Oktober 2025 bis 13. Februar 2026, Sommersemester 2026 vom 20. April
bis 24. Juli 2026. In den Prüfungsphasen dazwischen gibt es nur Stammtische.

Dieses Paket ist eine eigene Simulation. Jedes Paket hat eigene Datenfehler, wie sie in echten Vereinsdaten vorkommen.
Alle Personen und Daten sind erfunden.

## Dateien

- `personen.csv`: eine Zeile je Person (`person`, `studiengang`, `fachsemester_start` bei der ersten Anmeldung, `mitglied` 0 oder 1).
- `veranstaltungen.csv`: eine Zeile je Veranstaltung (`veranstaltung`, `datum`, `beginn`, `typ`, `thema`, `plaetze`, `catering` 0 oder 1).
- `anmeldungen.csv`: eine Zeile je Anmeldung.

| Spalte | Bedeutung |
|---|---|
| `anmeldung` | Kennung der Anmeldung |
| `veranstaltung` | Kennung der Veranstaltung, passt zu `veranstaltungen.csv` |
| `person` | Kennung der Person, passt zu `personen.csv` |
| `angemeldet_am` | Tag der Anmeldung (Text `JJJJ-MM-TT`) |
| `erinnerung` | 1, wenn die Person am Vorabend eine Erinnerung bekam, 0 wenn nicht; leer, wenn es keine Erinnerungen gab |
| `erschienen` | 1, wenn die Person gekommen ist, sonst 0 |

## Annahmen des Vorstands

- Eine Erinnerung kostet 0,10 Euro (Nachrichtendienst) und etwas Arbeit. Der Vorstand führt sie ein, wenn sie die
  Teilnahme um mindestens 3 Prozentpunkte erhöht.
- Mehr Personen als Plätze darf es höchstens bei einer von 20 Veranstaltungen geben (5 %). Bei Exkursionen fährt ein Bus
  mit 25 Plätzen: Hier soll es höchstens bei einer von 100 Exkursionen zu viele geben (1 %).
