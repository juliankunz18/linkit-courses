# Datenpaket B-04 · Track B · Nordwerk GmbH

Zustandsbasierte Wartung: lohnt sich der Rollout?

Seit dem 12. Januar 2026 läuft an acht Maschinen ein Pilot. Ein Warnsystem vergleicht jeden Produktionstag die
mittlere Schwingung mit dem Median der letzten 20 Produktionstage derselben Maschine. Liegt sie mehr als 35 % darüber,
gibt es einen Alarm, und die Instandhaltung macht noch am selben Tag eine Kurzinspektion (30 Minuten geplanter
Stillstand, 45 Minuten, wenn sie etwas findet). Für den Pilot hat die Instandhaltungsleitung die acht Maschinen mit
dem meisten ungeplanten Stillstand im 4. Quartal 2025 ausgewählt. Am 2. März 2026 hat der Einkauf an allen Maschinen
auf einen neuen Schmierstoff umgestellt.

Die Werkleitung fragt: Soll das Warnsystem auf weitere Maschinen ausgerollt werden, und wenn ja, auf welche?

Dieses Paket ist eine eigene Simulation des Werks. Die Zahlen weichen von den Kursdaten ab, und jedes Paket hat
eigene Datenfehler, wie sie in echten Werksdaten vorkommen. Alle Daten sind erfunden.

## Dateien

- `maschinen.csv`: eine Zeile je Maschine (`maschine`, `name`, `linie`, `typ`, `baujahr`, `pilot` mit 1 für die
  acht Pilotmaschinen, `pilot_start`).
- `maschinentage.csv`: eine Zeile je Maschine und Produktionstag vom 1. Oktober 2024 bis 29. September 2026.

| Spalte | Bedeutung |
|---|---|
| `datum` | Produktionstag (Text `JJJJ-MM-TT`) |
| `maschine` | Kennung `M-01` bis `M-20` |
| `laufzeit_h` | geplante Laufzeit an diesem Tag in Stunden (24 an Werktagen, 8 an Samstagen mit Frühschicht) |
| `vibration_mm_s` | mittlere Schwingstärke des Tages in mm/s |
| `lagertemp_c` | mittlere Lagertemperatur des Tages in Grad Celsius |
| `strom_pct` | mittlere Stromaufnahme in Prozent der Nennleistung |
| `stillstand_min` | ungeplanter Stillstand durch technische Störungen an diesem Tag in Minuten, auf 5 gerundet |
| `ausfall_morgen` | 1, wenn die Maschine am nächsten Produktionstag mindestens 60 Minuten ungeplant stillsteht, sonst 0 |
| `alarm` | 1, wenn das Warnsystem an diesem Tag anschlug, sonst 0; leer außerhalb des Pilots |
| `inspektion_min` | geplanter Stillstand durch die Kurzinspektion in Minuten; leer außerhalb des Pilots |

## Annahmen der Werkleitung

- Eine Minute ungeplanter Stillstand kostet 20 Euro.
- Eine Kurzinspektion kostet 400 Euro (geplanter Stillstand und Personal).
- Das Warnsystem kostet 5.000 Euro je Maschine und Jahr.
